﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hotel_Delux.Model_classes
{
    public class RoomImages
    {
        public int imgID { get; set; }
        public string imgName { get; set; }
        public string imgPath { get; set; }
        public int roomID { get; set; }
    }
}